<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%
  String type = request.getParameter("type");
  if(type == null) type = "";
%>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>点单 - 咩嘢熊仔咖啡</title>
  <style>
    * {margin:0;padding:0;box-sizing:border-box;font-family:"微软雅黑";}
    body {background:#FFF0DC;color:#5C4836;padding-bottom:70px;}
    .search-bar {padding:15px;background:#fff;display:flex;gap:10px;align-items:center;}
    .search-input {flex:1;padding:10px 14px;border:1px solid #E0CDB4;border-radius:20px;outline:none;background:#FFF9EF;}
    .coffee-container {padding:0 15px;display:grid;grid-template-columns:repeat(4,1fr);gap:12px;}
    .coffee-card {background:#fff;border-radius:14px;overflow:hidden;border:1px solid #E9D9C2;}
    .coffee-img {height:130px;background:#F7E9D6;display:flex;align-items:center;justify-content:center;font-size:50px;}
    .coffee-info {padding:10px;}
    .coffee-name {font-weight:bold;font-size:15px;margin-bottom:4px;}
    .coffee-price {color:#C9B48E;font-weight:bold;}
    .add-cart-btn {flex:1;padding:6px 0;background:#C9B48E;color:#fff;border:none;border-radius:12px;cursor:pointer;font-size:13px;}
    .buy-now-btn {flex:1;padding:6px 0;background:#fff;color:#C9B48E;border:1px solid #C9B48E;border-radius:12px;cursor:pointer;font-size:13px;}
    .btn-row {display:flex;gap:6px;margin-top:8px;}
    .footer-nav {position:fixed;bottom:0;left:0;width:100%;background:#fff;display:flex;padding:8px 0;border-top:1px solid #E9D9C2;}
    .nav-item {flex:1;text-align:center;font-size:14px;cursor:pointer;}
    .nav-item.active {color:#C9B48E;}
    .cart-badge {position:fixed;top:12px;right:15px;background:#C9B48E;color:#fff;width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:bold;z-index:100;cursor:pointer;}
    .spec-overlay {display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:9000;align-items:flex-end;justify-content:center;}
    .spec-overlay.show {display:flex;}
    .spec-panel {background:#fff;border-radius:20px 20px 0 0;width:100%;max-width:500px;max-height:85vh;overflow-y:auto;padding:20px 18px 30px;animation:slideUp 0.3s ease;}
    @keyframes slideUp {from{transform:translateY(100%)}to{transform:translateY(0)}}
    .spec-header {display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;}
    .spec-product {display:flex;align-items:center;gap:12px;}
    .spec-product-icon {width:50px;height:50px;background:#F7E9D6;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:28px;}
    .spec-product-name {font-weight:bold;font-size:16px;}
    .spec-product-price {color:#C9B48E;font-weight:bold;font-size:14px;margin-top:2px;}
    .spec-close {width:30px;height:30px;border-radius:50%;border:none;background:#F0E6D6;font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;}
    .spec-section {margin-bottom:16px;}
    .spec-label {font-size:14px;font-weight:bold;color:#5C4836;margin-bottom:8px;}
    .spec-chips {display:flex;flex-wrap:wrap;gap:8px;}
    .spec-chip {padding:7px 16px;border-radius:20px;border:1.5px solid #D9C3A8;background:#fff;color:#5C4836;font-size:13px;cursor:pointer;transition:0.15s;}
    .spec-chip.selected {background:#5C4836;color:#fff;border-color:#5C4836;}
    .spec-chip:hover:not(.selected) {background:#F3E2CD;}
    .spec-remark {width:100%;padding:10px 12px;border:1px solid #E0CDB4;border-radius:10px;outline:none;background:#FFF9EF;font-size:14px;resize:none;height:50px;}
    .spec-confirm-bar {display:flex;justify-content:space-between;align-items:center;margin-top:18px;padding-top:14px;border-top:1px solid #E9D9C2;}
    .spec-total {font-size:18px;font-weight:bold;color:#C9B48E;}
    .spec-cart-btn {padding:10px 28px;background:#C9B48E;color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:15px;}
    .spec-buy-btn {padding:10px 28px;background:#5C4836;color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:15px;}
    .spec-btn-group {display:flex;gap:10px;}
  </style>
</head>
<body>

<div class="search-bar">
  <input class="search-input" placeholder="搜索拿铁、美式、蛋糕...">
  <span>🔍</span>
</div>

<div class="cart-badge" onclick="location.href='cart.jsp'" id="cartBadge">0</div>

<div class="coffee-container">
  <% if(type.equals("") || type.equals("意式咖啡")){ %>
  <div class="coffee-card">
    <div class="coffee-img">☕</div>
    <div class="coffee-info">
      <div class="coffee-name">经典拿铁</div>
      <div class="coffee-price">¥22</div>
      <div class="btn-row">
        <button class="buy-now-btn" onclick="openSpec(1,'经典拿铁',22,'☕')">直接购买</button>
        <button class="add-cart-btn" onclick="openSpec(1,'经典拿铁',22,'☕')">加购</button>
      </div>
    </div>
  </div>
  <div class="coffee-card">
    <div class="coffee-img">🥤</div>
    <div class="coffee-info">
      <div class="coffee-name">焦糖玛奇朵</div>
      <div class="coffee-price">¥24</div>
      <div class="btn-row">
        <button class="buy-now-btn" onclick="openSpec(2,'焦糖玛奇朵',24,'🥤')">直接购买</button>
        <button class="add-cart-btn" onclick="openSpec(2,'焦糖玛奇朵',24,'🥤')">加购</button>
      </div>
    </div>
  </div>
  <% } %>

  <% if(type.equals("") || type.equals("甜品小食")){ %>
  <div class="coffee-card">
    <div class="coffee-img">🍰</div>
    <div class="coffee-info">
      <div class="coffee-name">提拉米苏</div>
      <div class="coffee-price">¥18</div>
      <div class="btn-row">
        <button class="buy-now-btn" onclick="openSpec(3,'提拉米苏',18,'🍰')">直接购买</button>
        <button class="add-cart-btn" onclick="openSpec(3,'提拉米苏',18,'🍰')">加购</button>
      </div>
    </div>
  </div>
  <% } %>

  <% if(type.equals("") || type.equals("特调饮品")){ %>
  <div class="coffee-card">
    <div class="coffee-img">🫧</div>
    <div class="coffee-info">
      <div class="coffee-name">荔枝气泡美式</div>
      <div class="coffee-price">¥26</div>
      <div class="btn-row">
        <button class="buy-now-btn" onclick="openSpec(4,'荔枝气泡美式',26,'🫧')">直接购买</button>
        <button class="add-cart-btn" onclick="openSpec(4,'荔枝气泡美式',26,'🫧')">加购</button>
      </div>
    </div>
  </div>
  <% } %>
</div>

<div class="footer-nav">
  <div class="nav-item" onclick="location.href='index.jsp'">首页</div>
  <div class="nav-item active" onclick="location.href='coffeeList.jsp'">点单</div>
  <div class="nav-item" onclick="location.href='cart.jsp'">购物车</div>
  <div class="nav-item" onclick="location.href='myOrder.jsp'">订单</div>
  <div class="nav-item" onclick="location.href='personal.jsp'">我的</div>
</div>

<!-- 规格选择弹窗 -->
<div class="spec-overlay" id="specOverlay">
  <div class="spec-panel">
    <div class="spec-header">
      <div class="spec-product">
        <div class="spec-product-icon" id="specIcon">☕</div>
        <div>
          <div class="spec-product-name" id="specName">商品名</div>
          <div class="spec-product-price" id="specPriceDisp">¥22</div>
        </div>
      </div>
      <button class="spec-close" onclick="closeSpec()">✕</button>
    </div>

    <div class="spec-section">
      <div class="spec-label">杯型</div>
      <div class="spec-chips" id="cupChips">
        <div class="spec-chip selected" onclick="selectChip(this,'cup')">中杯</div>
        <div class="spec-chip" onclick="selectChip(this,'cup')">大杯 (+¥3)</div>
      </div>
    </div>

    <div class="spec-section">
      <div class="spec-label">冷热</div>
      <div class="spec-chips" id="tempChips">
        <div class="spec-chip" onclick="selectChip(this,'temp')">热</div>
        <div class="spec-chip" onclick="selectChip(this,'temp')">常温</div>
        <div class="spec-chip selected" onclick="selectChip(this,'temp')">冰</div>
      </div>
    </div>

    <div class="spec-section">
      <div class="spec-label">甜度</div>
      <div class="spec-chips" id="sugarChips">
        <div class="spec-chip selected" onclick="selectChip(this,'sugar')">全糖</div>
        <div class="spec-chip" onclick="selectChip(this,'sugar')">七分糖</div>
        <div class="spec-chip" onclick="selectChip(this,'sugar')">半糖</div>
        <div class="spec-chip" onclick="selectChip(this,'sugar')">无糖</div>
      </div>
    </div>

    <div class="spec-section">
      <div class="spec-label">加料</div>
      <div class="spec-chips" id="toppingChips">
        <div class="spec-chip selected" onclick="selectChip(this,'topping')">无</div>
        <div class="spec-chip" onclick="selectChip(this,'topping')">珍珠 (+¥3)</div>
        <div class="spec-chip" onclick="selectChip(this,'topping')">椰果 (+¥3)</div>
        <div class="spec-chip" onclick="selectChip(this,'topping')">奶盖 (+¥5)</div>
      </div>
    </div>

    <div class="spec-section">
      <div class="spec-label">备注</div>
      <textarea class="spec-remark" id="specRemark" placeholder="少冰/不要吸管等"></textarea>
    </div>

    <div class="spec-confirm-bar">
      <div class="spec-total" id="specTotal">¥22</div>
      <div class="spec-btn-group">
        <button class="spec-cart-btn" onclick="confirmCart()">加入购物车</button>
        <button class="spec-buy-btn" onclick="confirmBuyNow()">直接购买</button>
      </div>
    </div>
  </div>
</div>

<script>
  var currentProduct = {id:0, name:'', price:0, icon:'☕'};

  function getContextPath() {
    var path = window.location.pathname;
    var idx = path.indexOf('/', 1);
    return idx > 0 ? path.substring(0, idx) : '';
  }

  function showToast(msg) {
    var existing = document.getElementById('toastMsg');
    if (existing) existing.remove();
    var toast = document.createElement('div');
    toast.id = 'toastMsg';
    toast.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(0,0,0,0.75);color:#fff;padding:14px 28px;border-radius:10px;font-size:15px;z-index:10000;opacity:1;transition:opacity 0.3s;';
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(function(){
      toast.style.opacity = '0';
      setTimeout(function(){ if(toast.parentNode) toast.remove(); }, 500);
    }, 1500);
  }

  function openSpec(id, name, price, icon) {
    currentProduct = {id:id, name:name, price:price, icon: icon || '☕'};
    document.getElementById('specIcon').textContent = currentProduct.icon;
    document.getElementById('specName').textContent = name;
    document.getElementById('specRemark').value = '';
    resetChips('cupChips');
    resetChips('tempChips');
    resetChips('sugarChips');
    resetChips('toppingChips');
    var tempChips = document.querySelectorAll('#tempChips .spec-chip');
    tempChips.forEach(function(c){ c.classList.remove('selected'); });
    tempChips[2].classList.add('selected');
    updateSpecPrice();
    document.getElementById('specOverlay').classList.add('show');
  }

  function closeSpec() {
    document.getElementById('specOverlay').classList.remove('show');
  }

  function resetChips(containerId) {
    var chips = document.querySelectorAll('#' + containerId + ' .spec-chip');
    chips.forEach(function(c, i){ c.classList.toggle('selected', i===0); });
  }

  function selectChip(el, group) {
    var parent = el.parentElement;
    var chips = parent.querySelectorAll('.spec-chip');
    chips.forEach(function(c){ c.classList.remove('selected'); });
    el.classList.add('selected');
    updateSpecPrice();
  }

  function getSelected(containerId) {
    var sel = document.querySelector('#' + containerId + ' .spec-chip.selected');
    return sel ? sel.textContent.replace(/\s*\(.*\)/, '').trim() : '';
  }

  function updateSpecPrice() {
    var cup = getSelected('cupChips');
    var topping = getSelected('toppingChips');
    var cupUp = (cup === '大杯') ? 3 : 0;
    var topUp = (topping === '珍珠') ? 3 : (topping === '椰果' ? 3 : (topping === '奶盖' ? 5 : 0));
    var total = currentProduct.price + cupUp + topUp;
    document.getElementById('specTotal').textContent = '¥' + total;
    document.getElementById('specPriceDisp').textContent = '¥' + total;
  }

  // ========== 加购：AJAX 无刷新 ==========
  function confirmCart() {
    var cup = getSelected('cupChips');
    var temp = getSelected('tempChips');
    var sugar = getSelected('sugarChips');
    var topping = getSelected('toppingChips');
    var remark = document.getElementById('specRemark').value.trim();
    var spec = cup + '/' + temp + '/' + sugar + '/' + topping;

    var contextPath = getContextPath();
    var xhr = new XMLHttpRequest();
    xhr.open('POST', contextPath + '/CartAddServlet', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    xhr.onload = function() {
      if (xhr.status === 200) {
        try {
          var result = JSON.parse(xhr.responseText);
          if (result.success) {
            if (result.cartSize) {
              document.getElementById('cartBadge').textContent = result.cartSize;
            }
            showToast('加入购物车成功 🛒');
            closeSpec();
          } else {
            showToast('加购失败：' + (result.message || '请重试'));
          }
        } catch(e) {
          showToast('加入购物车成功 🛒');
          closeSpec();
        }
      } else {
        showToast('加购失败，请重试');
      }
    };
    xhr.onerror = function() { showToast('网络错误，请重试'); };
    xhr.send('coffeeId=' + currentProduct.id + '&spec=' + encodeURIComponent(spec) + '&remark=' + encodeURIComponent(remark));
  }

  // ========== 直接购买：跳转结算页 ==========
  function confirmBuyNow() {
    var cup = getSelected('cupChips');
    var temp = getSelected('tempChips');
    var sugar = getSelected('sugarChips');
    var topping = getSelected('toppingChips');
    var remark = document.getElementById('specRemark').value.trim();
    var url = 'checkout.jsp?cid=' + currentProduct.id
            + '&cup=' + encodeURIComponent(cup)
            + '&temp=' + encodeURIComponent(temp)
            + '&sugar=' + encodeURIComponent(sugar)
            + '&topping=' + encodeURIComponent(topping)
            + '&remark=' + encodeURIComponent(remark);
    location.href = url;
  }
</script>
</body>
</html>